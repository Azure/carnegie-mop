CM_MODEL_WRAPPER_NAME = "inference"

